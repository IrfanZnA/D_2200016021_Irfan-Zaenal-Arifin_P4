import 'package:flutter/material.dart';

void main() => runApp(const ShrineApp());

class ShrineApp extends StatelessWidget {
  const ShrineApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shrine',
      initialRoute: '/login',
      routes: {
        '/login': (BuildContext context) => const LoginPage(),
        '/': (BuildContext context) => const HomePageScreen(),
      },
      theme: ThemeData.light(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: Colors.grey.shade200,
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _retypePasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 236, 198, 248),
        leading: Image.asset('assets/diamond.png', height: 32.0),
        title: const Text('Shrine', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24.0)),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          children: <Widget>[
            const SizedBox(height: 56.0),
            Column(
              children: <Widget>[
                Image.asset('assets/diamond.png', height: 64.0),
                const SizedBox(height: 16.0),
                const Text('REGISTRASI', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24.0)),
              ],
            ),
            const SizedBox(height: 40.0),
            const Text('Masukan Nama User', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0)),
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                labelText: 'Username',
                labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  borderSide: const BorderSide(color: Colors.blue, width: 1.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  borderSide: const BorderSide(color: Colors.blue, width: 1.0),
                ),
              ),
            ),
            const SizedBox(height: 16.0),
            const Text('Masukan Password', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0)),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(
                labelText: 'Password',
                labelStyle: const TextStyle(fontWeight: FontWeight.bold,fontSize: 16.0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  borderSide: const BorderSide(color: Colors.blue, width: 1.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  borderSide: const BorderSide(color: Colors.blue, width: 1.0),
                ),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 16.0),
            const Text('Masukan Kembali Password', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0)),
            TextField(
              controller: _retypePasswordController,
              decoration: InputDecoration(
                labelText: 'Password',
                labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  borderSide: const BorderSide(color: Colors.blue, width: 1.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  borderSide: const BorderSide(color: Colors.blue, width: 1.0),
                ),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 24.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                TextButton(
                  child: const Text('Hapus', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0)),
                  onPressed: () {
                    _usernameController.clear();
                    _passwordController.clear();
                    _retypePasswordController.clear();
                  },
                ),
                const SizedBox(width: 12.0),
                ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
                  ),
                  onPressed: () {
                    Navigator.pushReplacementNamed(context, '/');
                  },
                  child: const Text(
                    'Daftar',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0, color: Colors.white),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 150),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                TextButton(
                  child: const Text('Sudah Punya Akun?', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0)),
                  onPressed: () {
                    Navigator.pushReplacementNamed(context, '/login');
                  },
                ),
                TextButton(
                  child: const Text('Sign In', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0, color: Colors.blue)),
                  onPressed: () {
                    Navigator.pushReplacementNamed(context, '/login');
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class HomePageScreen extends StatelessWidget {
  const HomePageScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
      ),
      body: Center(
        child: const Text('Home Page'),
      ),
    );
  }
}
